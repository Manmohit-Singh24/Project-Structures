# REACT Front-end Project Structure

## Additional Libraries included :
 - `react-router`
 - `react-hook-forms`
 - `redux-toolkit`
 - `axios`
 
 You can run `npm install` command in beginning of using this project-structure to update all libraries.
 
