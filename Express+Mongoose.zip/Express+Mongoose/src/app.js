import express from "express";
import cookieParser from "cookie-parser";

const app = express();

app.use(express.json({ limit: "32kb" }));
app.use(cookieParser());

export default app;