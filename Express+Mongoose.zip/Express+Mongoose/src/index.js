import dotenv from "dotenv";
import app from "./app.js";
import { logger } from "./utils/index.js";

dotenv.config({
        path: "./.env"
});
logger.separator();
// ******************* App : *********************
const port = process.env.PORT;

app.listen(port, () => {
    logger.success("Server connected", `Server Running at port ${port}`);
});
 