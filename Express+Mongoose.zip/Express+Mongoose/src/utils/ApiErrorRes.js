const ApiErrorRes = (res, statusCode, message = "Something went wrong", data) => {
    res.status(statusCode).json({
        success: false,
        data: data, 
        message: message,
    });
};

export default ApiErrorRes;
