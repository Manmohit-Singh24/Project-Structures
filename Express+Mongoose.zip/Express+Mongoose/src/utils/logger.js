import winston from "winston";
import util from "util";
import fs from "fs";

class Logger {
    constructor() {
        if (!fs.existsSync("logs")) fs.mkdirSync("logs");

        // Themes for headings
        this.themes = {
            success: { style: "\x1b[42m\x1b[30m" }, // green bg + black text
            error: { style: "\x1b[41m\x1b[37m" }, // red bg + white text
            warn: { style: "\x1b[43m\x1b[30m" }, // yellow bg + black text
            info: { style: "\x1b[44m\x1b[37m" }, // blue bg + white text
            neutral: { style: "\x1b[100m\x1b[37m" }, // gray bg + white text
        };

        this.reset = "\x1b[0m";

        // Custom levels (adding `success`)
        const customLevels = {
            error: 0,
            warn: 1,
            success: 2,
            info: 3,
            debug: 4,
        };

        // Custom colors (Winston built-in colorize respects these)
        const customColors = {
            error: "red",
            warn: "yellow",
            success: "green",
            info: "blue",
            debug: "gray",
        };

        winston.addColors(customColors);

        // Development format (pretty & colorful, no timestamps)
        const consoleFormat = winston.format.combine(
            winston.format.colorize({ all: true }),
            winston.format.errors({ stack: true }),
            winston.format.printf((info) => {
                let msg = `${info.level} : ${info.message}`;
                if (info.data) {
                    msg += `\n${util.inspect(info.data, { depth: null, colors: true })}`;
                }
                return msg;
            }),
        );

        // Production format (JSON + timestamp)
        const logFilesFormat = winston.format.combine(
            winston.format.timestamp(),
            winston.format.errors({ stack: true }),
            winston.format.json(),
        );

        // Common transports
        this.transports = [
            new winston.transports.Console(),
            new winston.transports.File({
                filename: "logs/error.log",
                level: "error",
                format: logFilesFormat,
            }),
            new winston.transports.File({
                filename: "logs/combined.log",
                format: logFilesFormat,
            }),
        ];

        // Create Winston logger
        this.logger = winston.createLogger({
            levels: customLevels,
            level: "info",
            format: consoleFormat,
            transports: this.transports,
        });
    }

    // Core methods
    info(message, data) {
        this.logger.info(message, { data });
    }

    success(message, data) {
        this.heading(message, "success");
        this.logger.success(message, { data });
        this.separator();
    }

    warn(message, data) {
        this.heading(message, "warn");
        this.logger.warn(message, { data });
        this.separator();
    }

    error(message, error) {
        this.heading(message, "error");

        if (error instanceof Error) {
            this.logger.error(message, {
                stack: error.stack,
                name: error.name,
                message: error.message,
            });
        } else {
            this.logger.error(message, { data: error });
        }
        this.separator();
    }

    debug(message, data) {
        this.logger.debug(message, { data });
    }

    // Helpers
    heading(message, theme = "neutral") {
        if (this.isProd) return;
        const { style } = this.themes[theme] || this.themes.neutral;
        const styled = `\n${style} ${message.toUpperCase()} ${this.reset}`;
        console.log(styled);
    }

    separator(char = "-") {
        console.log(char.repeat(60));
    }
}

export const logger = new Logger();
