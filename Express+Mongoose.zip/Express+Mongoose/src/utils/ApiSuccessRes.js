const ApiSuccessRes = (res, statusCode, message = "Success", data) => {    
    res.status(statusCode).json({
        success: true,
        data: data,
        message: message,
    });
};

export default ApiSuccessRes;
